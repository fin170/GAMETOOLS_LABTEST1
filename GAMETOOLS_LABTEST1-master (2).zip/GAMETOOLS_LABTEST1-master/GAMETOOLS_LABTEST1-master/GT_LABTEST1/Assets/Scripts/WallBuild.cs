﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallBuild : MonoBehaviour
{
    public GameObject[] wallParts;
    void Start()
    {

        for (int a = 0; a < 11; a++)
        {
            for (int i = 0; i < 3; i++)
            {
                Instantiate(wallParts[i], new Vector3(a-5, i * 1f, 6), Quaternion.identity);
            }
        }
        for (int a = 0; a < 12; a++)
        {
            for (int i = 0; i < 3; i++)
            {
                Instantiate(wallParts[i], new Vector3(6, i * 1f, a-5), Quaternion.identity);
            }
        }


        for (int a = 0; a < 12; a++)
        {
            for (int i = 0; i < 3; i++)
            {
                Instantiate(wallParts[i], new Vector3(-6, i * 1f,a-5), Quaternion.identity);
            }
        }

        for (int a = 0; a < 5; a++)
        {
            for (int i = 0; i < 3; i++)
            {
                Instantiate(wallParts[i], new Vector3(-6+a, i * 1f, -6), Quaternion.identity);
            }
        }

        for (int a = 0; a < 5; a++)
        {
            for (int i = 0; i < 3; i++)
            {
                Instantiate(wallParts[i], new Vector3(6 - a, i * 1f, -6), Quaternion.identity);
            }
        }



    }

    // Update is called once per frame
    void Update()
    {
      
    }
}
